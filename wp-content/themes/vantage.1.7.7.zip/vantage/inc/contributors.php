<?php
return json_decode( '{
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1786,
		"score": 54.25008519949269,
		"percent": 37.26010570663954
	},
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 927,
		"score": 48.43649571727467,
		"percent": 33.26720951401796
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 2341,
		"score": 25.669086979929695,
		"percent": 17.630071745473487
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 165,
		"score": 14.398080307865404,
		"percent": 9.8889060223774
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 19,
		"score": 1.3826036154720178,
		"percent": 0.9496014001347808
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 25,
		"score": 0.7729188070879992,
		"percent": 0.5308569811244812
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 2,
		"score": 0.5265587517326658,
		"percent": 0.3616516854889431
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 21,
		"score": 0.1624832685124298,
		"percent": 0.11159694474341667
	}
}', true );